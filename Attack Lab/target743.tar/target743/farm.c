/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_312(unsigned *p)
{
    *p = 3276296927U;
}

void setval_309(unsigned *p)
{
    *p = 2421688511U;
}

unsigned getval_278()
{
    return 3284634056U;
}

unsigned addval_257(unsigned x)
{
    return x + 3347664041U;
}

unsigned addval_400(unsigned x)
{
    return x + 3347663055U;
}

unsigned getval_485()
{
    return 2488816879U;
}

unsigned addval_119(unsigned x)
{
    return x + 3347662976U;
}

unsigned addval_368(unsigned x)
{
    return x + 2421734670U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_245(unsigned *p)
{
    *p = 2425409929U;
}

unsigned getval_155()
{
    return 3526935049U;
}

unsigned addval_217(unsigned x)
{
    return x + 2428668357U;
}

unsigned addval_209(unsigned x)
{
    return x + 3677933993U;
}

unsigned getval_103()
{
    return 12832265U;
}

unsigned addval_275(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_190()
{
    return 3525365449U;
}

unsigned addval_458(unsigned x)
{
    return x + 3677405833U;
}

unsigned addval_412(unsigned x)
{
    return x + 3676360329U;
}

unsigned addval_241(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_429(unsigned x)
{
    return x + 3680551561U;
}

unsigned addval_443(unsigned x)
{
    return x + 2496563700U;
}

unsigned getval_326()
{
    return 3286272328U;
}

unsigned addval_300(unsigned x)
{
    return x + 3286288712U;
}

void setval_191(unsigned *p)
{
    *p = 3374371208U;
}

unsigned getval_393()
{
    return 3525365387U;
}

unsigned addval_299(unsigned x)
{
    return x + 3286276424U;
}

void setval_462(unsigned *p)
{
    *p = 3677933961U;
}

unsigned getval_178()
{
    return 3353381192U;
}

void setval_247(unsigned *p)
{
    *p = 146984585U;
}

void setval_184(unsigned *p)
{
    *p = 2425406089U;
}

unsigned addval_234(unsigned x)
{
    return x + 3531129481U;
}

unsigned addval_494(unsigned x)
{
    return x + 3676881545U;
}

unsigned addval_281(unsigned x)
{
    return x + 3381969545U;
}

unsigned getval_472()
{
    return 3682914696U;
}

unsigned getval_431()
{
    return 3286272264U;
}

unsigned getval_192()
{
    return 2496760246U;
}

unsigned addval_354(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_237()
{
    return 3682913933U;
}

unsigned addval_118(unsigned x)
{
    return x + 2425409945U;
}

void setval_480(unsigned *p)
{
    *p = 3229143433U;
}

unsigned getval_116()
{
    return 3285092692U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
